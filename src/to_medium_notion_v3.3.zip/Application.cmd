start binc.exe util.txt
